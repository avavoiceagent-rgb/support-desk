export type TicketStatus =
  | "OPEN"
  | "IN_PROGRESS"
  | "AWAITING_CUSTOMER"
  | "AWAITING_DISPATCH"
  | "NO_RESPONSE"
  | "FOLLOW_UP"
  | "ESCALATED"
  | "FEEDBACK"
  | "AFFILIATE"
  | "RESOLVED_CLOSED"
  | "UNRESOLVED_CLOSED";

export type TicketQueue = "RESERVATION" | "DISPATCH" | "ACCOUNTING";
export type TicketChannel = "EMAIL" | "PHONE";
export type UserRole = "ADMIN" | "AGENT";

export interface PublicUser {
  id: string;
  email: string;
  name: string;
  role: UserRole;
}

export interface TicketListItem {
  id: string;
  ticketNumber: number;
  subject: string;
  requesterEmail: string | null;
  requesterName: string | null;
  requesterPhone: string | null;
  status: TicketStatus;
  queue: TicketQueue | null;
  channel: TicketChannel;
  assignee: { id: string; name: string; email: string } | null;
  mailbox: string;
  createdAt: string;
  updatedAt: string;
  receivedAt: string;
  firstReplyAt: string | null;
  lastMessagePreview: { direction: "INBOUND" | "OUTBOUND"; snippet: string; sentAt: string } | null;
}

export interface Attachment {
  id: string;
  messageId: string;
  providerAttachmentId: string;
  filename: string;
  mimeType: string;
  size: number;
}

export interface TicketMessage {
  id: string;
  ticketId: string;
  direction: "INBOUND" | "OUTBOUND";
  authorId: string | null;
  author: PublicUser | null;
  fromAddress: string;
  toAddresses: string[];
  ccAddresses: string[];
  subject: string;
  bodyHtml: string;
  bodyText: string | null;
  isAutoReply: boolean;
  sentAt: string;
  attachments: Attachment[];
}

export interface TicketNote {
  id: string;
  ticketId: string;
  authorId: string;
  author: PublicUser;
  body: string;
  createdAt: string;
}

export interface TicketDetail {
  id: string;
  ticketNumber: number;
  subject: string;
  requesterEmail: string | null;
  requesterName: string | null;
  requesterPhone: string | null;
  status: TicketStatus;
  queue: TicketQueue | null;
  channel: TicketChannel;
  providerThreadId: string;
  emailAccountId: string;
  assigneeId: string | null;
  assignee: PublicUser | null;
  emailAccount: { id: string; email: string; provider: "GMAIL" | "OUTLOOK" };
  createdAt: string;
  updatedAt: string;
  messages: TicketMessage[];
  notes: TicketNote[];
}

export interface TicketHistoryItem {
  id: string;
  ticketNumber: number;
  subject: string;
  status: TicketStatus;
  requesterEmail: string | null;
  requesterName: string | null;
  updatedAt: string;
  snippet: string;
}

export interface DashboardStats {
  totalTickets: number;
  byStatus: Record<string, number>;
  byQueue: Record<string, number>;
  byChannel: Record<string, number>;
  agents: { id: string | null; name: string; open: number; closed: number; total: number }[];
  sla: {
    targetHours: number;
    repliedCount: number;
    repliedWithinTarget: number;
    avgFirstReplyMs: number | null;
    awaitingReply: number;
    awaitingOverdue: number;
  };
  volume: { day: string; count: number }[];
}

export interface EmailAccountStatus {
  id: string;
  provider: "GMAIL" | "OUTLOOK";
  email: string;
  status: string;
  lastError: string | null;
  connectedAt: string;
}
